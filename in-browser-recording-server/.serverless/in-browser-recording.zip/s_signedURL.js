var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'bruss63',
applicationName: 'in-browser-recording',
appUid: 'c3kbZhMmQn68LbCpmr',
tenantUid: 'MBR8gCqbFFnMkp6MFx',
deploymentUid: 'cd70a0cb-b397-47f3-b07e-f23463bf2dbb',
serviceName: 'in-browser-recording',
stageName: 'dev',
pluginVersion: '3.2.7'})
const handlerWrapperArgs = { functionName: 'in-browser-recording-dev-signedURL', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.signedURL, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
